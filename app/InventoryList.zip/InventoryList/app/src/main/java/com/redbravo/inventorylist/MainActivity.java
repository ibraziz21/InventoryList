package com.redbravo.inventorylist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sell(View view) {

    }
    public void newProduct(View view){
        Intent intent= new Intent(this,Add_product.class);
        startActivity(intent);
    }
    public void StockProduct(View view){

    }
}